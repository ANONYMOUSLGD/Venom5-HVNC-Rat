namespace VenomRAT_HVNC.Server
{
    internal class Client
    {
    }
}
