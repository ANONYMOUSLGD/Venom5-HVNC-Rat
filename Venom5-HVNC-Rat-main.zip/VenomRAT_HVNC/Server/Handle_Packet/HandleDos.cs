using Server.MessagePack;
using VenomRAT_HVNC.Server.Connection;

namespace VenomRAT_HVNC.Server.Handle_Packet
{
    internal class HandleDos
    {
        public void Add(Clients client, MsgPack unpack_msgpack)
        {
        }
    }
}
